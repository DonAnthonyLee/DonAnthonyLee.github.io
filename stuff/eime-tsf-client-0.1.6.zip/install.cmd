cd /d %~dp0

if "%PROCESSOR_ARCHITECTURE%"=="AMD64" regsvr32 eime-tsf.dll

REM The file "eime-tsf-x86.dll" is necessary for running x86 program on x64 system.
REM DO NOT REMOVE IT, PLEASE.

if "%PROCESSOR_ARCHITECTURE%"=="X86" regsvr32 eime-tsf-x86.dll

