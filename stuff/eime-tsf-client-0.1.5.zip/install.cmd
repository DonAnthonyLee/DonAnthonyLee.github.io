cd /d %~dp0

if "%PROCESSOR_ARCHITECTURE%"=="AMD64" regsvr32 eime-tsf.dll
regsvr32 eime-tsf-x86.dll

