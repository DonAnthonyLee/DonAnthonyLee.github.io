cd /d %~dp0
if "%PROCESSOR_ARCHITECTURE%"=="AMD64" regsvr32 /u eime-tsf.dll
regsvr32 /u eime-tsf-x86.dll
